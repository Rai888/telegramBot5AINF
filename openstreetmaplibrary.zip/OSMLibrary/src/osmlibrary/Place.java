/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osmlibrary;

/**
 *
 * @author Riccardo
 */
public class Place {
    private double lat, lon;
    private String city, town, street;

    public Place() {
        town="";
    }

    public Place(double lat, double lon) {
        this.lat = lat;
        this.lon = lon;
    }

    

    public void setLat(double lat) {
        this.lat = lat;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public void setStreet(String street) {
        this.street = street;
    }
    
    
    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }

    public String getCity() {
        return city;
    }

    public String getTown() {
        return town;
    }

    public String getStreet() {
        return street;
    }
    
    
}
